package com.example.dllo.a36kr.ui.fragment;

import com.example.dllo.a36kr.R;

/**
 * Created by dllo on 16/9/23.
 * 我的详情注册Fragment
 */
public class RegisterFragment extends AbsFragment {
    @Override
    protected int setLayout() {
        return R.layout.item_unlogin_register;
    }

    @Override
    protected void initViews() {

    }

    @Override
    protected void initDatas() {

    }
}
