package com.example.dllo.a36kr.view;

/**
 * 轮播图的实体类
 */
public class LoopViewEntity {
    private String imageUrl;
    private String descript;

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getDescript() {
        return descript;
    }

    public void setDescript(String descript) {
        this.descript = descript;
    }
}
