package com.example.dllo.a36kr.model.net;

/**
 * Created by dllo on 16/9/9.
 * 网络请求接口
 */
public interface VolleyReault {
    void success(String resultStr);
    void failure();
}
