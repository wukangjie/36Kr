package com.example.dllo.a36kr.ui.activity;

/**
 * Created by dllo on 16/9/21.
 * 接口回调方法接口
 */
public interface ItoContralActivity {
    void toContralActivity(boolean state);
}
