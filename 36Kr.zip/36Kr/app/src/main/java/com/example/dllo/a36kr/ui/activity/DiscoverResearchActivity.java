package com.example.dllo.a36kr.ui.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.dllo.a36kr.R;

/**
 * 创业公司详情页
 */

public class DiscoverResearchActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discover_research);
    }
}
