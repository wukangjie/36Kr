package com.example.dllo.a36kr.ui.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.dllo.a36kr.R;

/**
 * 发现创业公司的详情页
 */
public class DiscoverCreateActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discover_create);
    }
}
